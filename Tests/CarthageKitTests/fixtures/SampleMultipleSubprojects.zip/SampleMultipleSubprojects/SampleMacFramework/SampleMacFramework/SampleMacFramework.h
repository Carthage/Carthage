//
//  SampleMacFramework.h
//  SampleMacFramework
//
//  Created by pivotal on 11/4/15.
//
//

#import <Cocoa/Cocoa.h>

//! Project version number for SampleMacFramework.
FOUNDATION_EXPORT double SampleMacFrameworkVersionNumber;

//! Project version string for SampleMacFramework.
FOUNDATION_EXPORT const unsigned char SampleMacFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SampleMacFramework/PublicHeader.h>



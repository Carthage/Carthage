//
//  TestScreensaverPluginView.h
//  TestScreensaverPlugin
//
//  Created by ich on 05.08.19.
//  Copyright © 2019 relikd. All rights reserved.
//

#import <ScreenSaver/ScreenSaver.h>

@interface TestScreensaverPluginView : ScreenSaverView

@end

// Make sure this is compiled as a Swift framework.
import TestFramework3

public let Name = "Framework2"

public func UseFrameworks() {
    print("\(Name) has dependencies:")

    TestFramework3.UseFrameworks()
}

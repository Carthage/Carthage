//
//  TestFile.swift
//  TestFramework
//
//  Created by Nikolay Ischuk on 07.04.2018.
//

import Foundation

func testFunction() {
    print("Hello")
}

//
//  TestFramework2_iOS.h
//  TestFramework2_iOS
//
//  Created by Stephen Marquis on 2/22/17.
//
//

#import <UIKit/UIKit.h>

//! Project version number for TestFramework2_iOS.
FOUNDATION_EXPORT double TestFramework2_iOSVersionNumber;

//! Project version string for TestFramework2_iOS.
FOUNDATION_EXPORT const unsigned char TestFramework2_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework2_iOS/PublicHeader.h>



// Make sure this is compiled as a Swift framework.
public let Name = "Framework 3"

public func UseFrameworks() {
    print("\(Name) has no dependencies")
}

//  Copyright (c) 2014 Rob Rix. All rights reserved.

/// Project version number for Prelude.
extern double PreludeVersionNumber;

/// Project version string for Prelude.
extern const unsigned char PreludeVersionString[];


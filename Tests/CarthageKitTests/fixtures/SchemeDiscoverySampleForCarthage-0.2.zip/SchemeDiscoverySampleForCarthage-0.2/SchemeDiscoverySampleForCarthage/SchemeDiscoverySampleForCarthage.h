//
//  SchemeDiscoverySampleForCarthage.h
//  SchemeDiscoverySampleForCarthage
//
//  Created by Syo Ikeda on 10/5/15.
//  Copyright © 2015 Syo Ikeda. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SchemeDiscoverySampleForCarthage.
FOUNDATION_EXPORT double SchemeDiscoverySampleForCarthageVersionNumber;

//! Project version string for SchemeDiscoverySampleForCarthage.
FOUNDATION_EXPORT const unsigned char SchemeDiscoverySampleForCarthageVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SchemeDiscoverySampleForCarthage/PublicHeader.h>



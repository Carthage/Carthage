//
//  TestFramework2_Mac.h
//  TestFramework2_Mac
//
//  Created by Stephen Marquis on 2/22/17.
//
//

#import <Cocoa/Cocoa.h>

//! Project version number for TestFramework2_Mac.
FOUNDATION_EXPORT double TestFramework2_MacVersionNumber;

//! Project version string for TestFramework2_Mac.
FOUNDATION_EXPORT const unsigned char TestFramework2_MacVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework2_Mac/PublicHeader.h>



// Make sure this is compiled as a Swift framework.
import TestFramework2
import TestFramework3

public let Name = "Framework1"

public func UseFrameworks() {
    print("\(Name) has dependencies:")

    TestFramework2.UseFrameworks()
    TestFramework3.UseFrameworks()
}

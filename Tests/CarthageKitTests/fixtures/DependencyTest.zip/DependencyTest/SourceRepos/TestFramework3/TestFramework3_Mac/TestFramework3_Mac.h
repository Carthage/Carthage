//
//  TestFramework3_Mac.h
//  TestFramework3_Mac
//
//  Created by Stephen Marquis on 2/22/17.
//
//

#import <Cocoa/Cocoa.h>

//! Project version number for TestFramework3_Mac.
FOUNDATION_EXPORT double TestFramework3_MacVersionNumber;

//! Project version string for TestFramework3_Mac.
FOUNDATION_EXPORT const unsigned char TestFramework3_MacVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework3_Mac/PublicHeader.h>



//
//  AuxiliaryFramework.h
//  AuxiliaryFramework
//
//  Created by Justin Spahr-Summers on 2014-11-26.
//  Copyright (c) 2014 GitHub. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for AuxiliaryFramework.
FOUNDATION_EXPORT double AuxiliaryFrameworkVersionNumber;

//! Project version string for AuxiliaryFramework.
FOUNDATION_EXPORT const unsigned char AuxiliaryFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AuxiliaryFramework/PublicHeader.h>



//
//  main.swift
//  SwellOSXDemo2
//
//  Created by Hubert Rabago on 7/20/14.
//  Copyright (c) 2014 Minute Apps LLC. All rights reserved.
//

import Cocoa

NSApplicationMain(Process.argc, Process.unsafeArgv)

//
//  SampleGitSubmodule.h
//  SampleGitSubmodule
//
//  Created by Rachel Brindle on 12/14/15.
//  Copyright © 2015 examplecorp. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SampleGitSubmodule.
FOUNDATION_EXPORT double SampleGitSubmoduleVersionNumber;

//! Project version string for SampleGitSubmodule.
FOUNDATION_EXPORT const unsigned char SampleGitSubmoduleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SampleGitSubmodule/PublicHeader.h>



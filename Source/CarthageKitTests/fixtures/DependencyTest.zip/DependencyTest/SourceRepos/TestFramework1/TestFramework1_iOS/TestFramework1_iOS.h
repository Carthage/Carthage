//
//  TestFramework1_iOS.h
//  TestFramework1_iOS
//
//  Created by Stephen Marquis on 2/22/17.
//
//

#import <UIKit/UIKit.h>

//! Project version number for TestFramework1_iOS.
FOUNDATION_EXPORT double TestFramework1_iOSVersionNumber;

//! Project version string for TestFramework1_iOS.
FOUNDATION_EXPORT const unsigned char TestFramework1_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework1_iOS/PublicHeader.h>



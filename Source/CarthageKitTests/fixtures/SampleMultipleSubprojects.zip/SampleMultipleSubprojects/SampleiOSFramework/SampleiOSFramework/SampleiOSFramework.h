//
//  SampleiOSFramework.h
//  SampleiOSFramework
//
//  Created by pivotal on 11/4/15.
//
//

#import <UIKit/UIKit.h>

//! Project version number for SampleiOSFramework.
FOUNDATION_EXPORT double SampleiOSFrameworkVersionNumber;

//! Project version string for SampleiOSFramework.
FOUNDATION_EXPORT const unsigned char SampleiOSFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SampleiOSFramework/PublicHeader.h>



//
//  TestFramework1.h
//  TestFramework1
//
//  Created by Stephen Marquis on 2/22/17.
//
//

#import <Cocoa/Cocoa.h>

//! Project version number for TestFramework1.
FOUNDATION_EXPORT double TestFramework1VersionNumber;

//! Project version string for TestFramework1.
FOUNDATION_EXPORT const unsigned char TestFramework1VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework1/PublicHeader.h>



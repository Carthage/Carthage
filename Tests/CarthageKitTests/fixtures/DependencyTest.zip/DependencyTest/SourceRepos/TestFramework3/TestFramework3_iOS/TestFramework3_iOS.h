//
//  TestFramework3_iOS.h
//  TestFramework3_iOS
//
//  Created by Stephen Marquis on 2/22/17.
//
//

#import <UIKit/UIKit.h>

//! Project version number for TestFramework3_iOS.
FOUNDATION_EXPORT double TestFramework3_iOSVersionNumber;

//! Project version string for TestFramework3_iOS.
FOUNDATION_EXPORT const unsigned char TestFramework3_iOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework3_iOS/PublicHeader.h>



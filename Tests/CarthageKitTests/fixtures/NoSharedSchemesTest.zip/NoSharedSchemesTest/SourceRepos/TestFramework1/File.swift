// Make sure this is compiled as a Swift framework.
public let Name = "Framework1"

public func UseFrameworks() {
    print("\(Name) has no dependencies with shared schemes.")
}

//
//  SampleWatchFramework.h
//  SampleWatchFramework
//
//  Created by pivotal on 11/4/15.
//
//

#import <WatchKit/WatchKit.h>

//! Project version number for SampleWatchFramework.
FOUNDATION_EXPORT double SampleWatchFrameworkVersionNumber;

//! Project version string for SampleWatchFramework.
FOUNDATION_EXPORT const unsigned char SampleWatchFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SampleWatchFramework/PublicHeader.h>



//
//  Swell.h
//  Swell
//
//  Created by Hubert Rabago on 6/20/14.
//  Copyright (c) 2014 Minute Apps LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Swell.
FOUNDATION_EXPORT double SwellVersionNumber;

//! Project version string for Swell.
FOUNDATION_EXPORT const unsigned char SwellVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Swell/PublicHeader.h>

//#import "Swell/Swell-Swift.h"

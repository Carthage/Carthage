// Make sure this is compiled as a Swift framework.
let test = "test"

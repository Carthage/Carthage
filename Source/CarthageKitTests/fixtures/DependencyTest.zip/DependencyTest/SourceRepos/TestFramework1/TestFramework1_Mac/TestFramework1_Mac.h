//
//  TestFramework1_Mac.h
//  TestFramework1_Mac
//
//  Created by Stephen Marquis on 2/22/17.
//
//

#import <Cocoa/Cocoa.h>

//! Project version number for TestFramework1_Mac.
FOUNDATION_EXPORT double TestFramework1_MacVersionNumber;

//! Project version string for TestFramework1_Mac.
FOUNDATION_EXPORT const unsigned char TestFramework1_MacVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TestFramework1_Mac/PublicHeader.h>


